共五个文件：
code1.py  ：其中使用的策略是完全随机，代码有“可视化”效果。
code1-Q-learning.py ：使用的策略是Q-learning法，代码主要参考网上博客，实现训练和胜负结果统计。
code1-results.py ：这里我利用chatgpt帮我统计了三种因子变化对应的结果，由于时间原因，没得出什么结论，快要吃饭了。
还有一个txt文档：记录一下利用chatgpt对Q-learning法的学习内容。